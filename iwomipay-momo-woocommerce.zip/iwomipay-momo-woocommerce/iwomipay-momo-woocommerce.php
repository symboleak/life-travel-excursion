<?php
/**
 * Plugin Name: MTN Mobile Money (via IWOMIPAY) for WooCommerce
 * Plugin URI: https://www.pay.iwomitechnologies.com/
 * Description: MTN Mobile Mobile Money Seemless Payment For Woocommerce
 * Author: IWOMI TECHNOLOGIES LTD
 * Author URI: https://www.iwomitechnologies.com/
 * Version: 1.0.3
 * Text Domain: wc-iwomipay-momo
 * Domain Path: /i18n/languages/
 * Developer: Jifitech Group, Inc.
 * Requires at least: 5.5
 * Tested up to: 5.7.1
 * Requires PHP: 7.2
 * License: GPLv2 or later
 * License URL: http://www.gnu.org/licenses/gpl-2.0.txt
 * Copyright: (c) 2021 IWOMI TECHNOLOGIES LTD. (info@iwomitechnologies.com) and WooCommerce
 *
 * @package   WC-Iwomipay-MOMO
 * @author    IWOMI TECHNOLOGIES LTD
 * @category  Admin
 * @copyright Copyright: (c) 2021 IWOMI TECHNOLOGIES LTD. (info@iwomitechnologies.com) and WooCommerce
 * @license   http://www.gnu.org/licenses/gpl-2.0.txt
 *
 * MTN Mobile Mobile Money Seemless Payment For Woocommerce, Fast, secured and easy payment gateway.
 */
 
defined( 'ABSPATH' ) or exit;

$GLOBALS['ciphering'] = "AES-128-CTR";

// Use OpenSSl Encryption method 
$GLOBALS['iv_length'] = openssl_cipher_iv_length($GLOBALS['ciphering']);

// Non-NULL Initialization Vector for encryption 
$GLOBALS['encryption_iv'] = '1234567891011121';

// Store the encryption / decryption key 
$GLOBALS['ecryption_key'] = "IwoMiPaySaddI";

$GLOBALS['options_key'] = 0;

// Use openssl_encrypt() function to encrypt the data 
// $GLOBALS['encryption'] = openssl_encrypt($simple_string, $ciphering, $encryption_key, $options, $encryption_iv); 
$GLOBALS['encryption'] = "1JCmtBpuWTzopyYFhzgRHU0rvKAyt5H+qJFfAdl/jcCk2JrDm2DIlA==";

// Use openssl_decrypt() function to decrypt the data 
$GLOBALS['decryption'] = openssl_decrypt(
    $GLOBALS['encryption'],
    $GLOBALS['ciphering'],
    $GLOBALS['ecryption_key'],
    $GLOBALS['options_key'],
    $GLOBALS['encryption_iv']
);

// Make sure WooCommerce is active
if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	return;
}

$iwomipay_gateway_defined = 'momo';

/**
 * Add the gateway to WC Available Gateways
 * 
 * @since 1.0.0
 * @param array $gateways all available WC gateways
 * @return array $gateways all WC gateways + offline gateway
 */
function wc_iwomipay_momo( $gateways ) {
    
    global $iwomipay_gateway_defined;
	$gateways[] = 'WC_' . ucfirst($iwomipay_gateway_defined) . '_Iwomipay';
	return $gateways;
}
add_filter( 'woocommerce_payment_gateways', 'wc_iwomipay_' . $iwomipay_gateway_defined);

/**
 * Adds plugin page links
 * 
 * @since 1.0.0
 * @param array $links all plugin links
 * @return array $links all plugin links + our custom links (i.e., "Settings")
 */
function wc_iwomipay_momo_plugin_links( $links ) {

    global $iwomipay_gateway_defined;
	$plugin_links = array(
		'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=iwomipay_' . $iwomipay_gateway_defined . '_settings' ) . '">' . __( 'Configure', 'wc-iwomipay-' . $iwomipay_gateway_defined ) . '</a>'
	);

	return array_merge( $plugin_links, $links );
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'wc_iwomipay_' . $iwomipay_gateway_defined . '_plugin_links' );

/**
 * Iwomipay Payment Gateway
 *
 * Provides an Offline Payment Gateway; mainly for testing purposes.
 * We load it later to ensure WC is loaded first since we're extending it.
 *
 * @class 		WC_Momo_Iwomipay
 * @extends		WC_Payment_Gateway
 * @version		1.0.0
 * @package		WooCommerce/Classes/Payment
 * @author 		SkyVerge
 */
add_action( 'plugins_loaded', 'wc_iwomipay_' . $iwomipay_gateway_defined . '_paiment_init', 11 );

function wc_iwomipay_momo_paiment_init() {

    global $iwomipay_gateway_defined;
	if (class_exists('WC_Payment_Gateway')) {
        require_once plugin_dir_path(__FILE__) . '/inc/class-iwomipay-' . $iwomipay_gateway_defined . '-gateway.php';
        require_once plugin_dir_path(__FILE__) . '/inc/class-iwomipay-' . $iwomipay_gateway_defined . '-updater.php';


        new Iwomipay_MOMO_Updater( __FILE__, 'mrnjifanda', 'woocommerce-iwomipay-' . $iwomipay_gateway_defined . '-plugin' );
    }
	// end \WC_Momo_Iwomipay class
}

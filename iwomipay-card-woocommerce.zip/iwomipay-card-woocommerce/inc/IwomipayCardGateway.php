<?php

class IwomipayCardGateway extends WC_Payment_Gateway
{

    /**
     * Constructor for the gateway.
     */
    public function __construct()
    {

        $this->gateway = 'card';

        $this->id                 = 'iwomipay_payment_' . $this->gateway;
        $this->icon               = apply_filters('woocommerce_iwomipay_icon',  plugins_url('../assets/' . $this->gateway . '-32.jpg', __FILE__));
        $this->has_fields         = false;
        $this->method_title       = __('Card (via IWOMIPAY)', $this->iwomipay_get_id());
        $this->method_description = __('Card. Seemless Payment For Woocommerce', $this->iwomipay_get_id());

        // Load the settings.
        $this->init_form_fields();
        $this->init_settings();

        // Define user set variables
        $this->sectionOne   = $this->get_option('sectionOne');
        $this->title        = $this->get_option('title');
        $this->description  = $this->get_option('description');

        /**
         * Production mode credentials
         */
        $this->sectionTwo = $this->get_option('sectionTwo');

        // Account Identifiants
        $this->iwomipayUser = $this->iwomipay_init_fields('iwomipayUser');
        $this->iwomipayPassword = $this->iwomipay_init_fields('iwomipayPassword');

        // Credit Credentials 
        $this->iwomipayCrediKey = $this->iwomipay_init_fields('iwomipayCrediKey');
        $this->iwomipayCrediSecret = $this->iwomipay_init_fields('iwomipayCrediSecret');

        /**
         * Sandbox mode credentials
         */
        $this->sectionThree = $this->get_option('sectionThree');

        // Account Identifiants
        $this->iwomipayUserSandbox = $this->iwomipay_init_fields('iwomipayUserSandbox');
        $this->iwomipayPasswordSandbox = $this->iwomipay_init_fields('iwomipayPasswordSandbox');

        // Credit Credentials 
        $this->iwomipayCrediKeySandbox = $this->iwomipay_init_fields('iwomipayCrediKeySandbox');
        $this->iwomipayCrediSecretSandbox = $this->iwomipay_init_fields('iwomipayCrediSecretSandbox');

        // Base Url
        $this->sectionFour = $this->get_option('sectionFour');
        $this->iwomipayApiBaseUrl = $this->iwomipay_init_fields('apiBaseUrl');
        $this->iwomipayApiBaseUrlSandbox = $this->iwomipay_init_fields('apiBaseUrlSandbox');
        $this->iwomipayEnvironment = $this->iwomipay_init_fields('environment');

        $this->iwomipayOptions = [];
        $this->iwomipayToken = [
            'token' => null,
            'expired_time' => null
        ];

        // Actions
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));

        // Customer Emails
        // add_action('woocommerce_email_before_order_table', array($this, 'email_instructions'), 10, 3);
    }

    public function iwomipay_get_id(): string
    {
    
        return 'wc-iwomipay-' . $this->gateway;
    }

    public function iwomipay_init_fields(string $option): string
    {

        return $this->get_option($option . $this->gateway);
    }

    public function iwomipay_get_fields(string $field): string
    {

        return $field . $this->gateway;
    }

    public function iwomipay_set_field(string $field, string $type = 'text', string $default = 'xxx', string $description = ''): array
    {

        return array(
            'title' => __($field, $this->iwomipay_get_id()),
            'type' => $type,
            'default' => __($default, $this->iwomipay_get_id()),
            'desc_tip' => true,
            'description' => __($description, $this->iwomipay_get_id())
        );
    }

    //Initialize Gateway Settings Form Fields
    public function init_form_fields()
    {

        $this->form_fields = apply_filters('wc_iwomipay_fields', array(

            'sectionOne' => array(
                'title' => __('Global Settings', $this->iwomipay_get_id()),
                'type' => 'title',
            ),
            'enabled' => array(
                'title'   => __('Enable/Disable', $this->iwomipay_get_id()),
                'type'    => 'checkbox',
                'label'   => __('Enable or Disable Iwomipay ' . strtoupper($this->gateway) . ' Payments', $this->iwomipay_get_id()),
                'default' => 'no'
            ),
            'title' => array(
                'title'       => __('Gateway Title', $this->iwomipay_get_id()),
                'type'        => 'text',
                'description' => __('Tire that will be displayed on your checkout page', $this->iwomipay_get_id()),
                'default'     => __('Visa/Mastercard (via IWOMIPAY)', $this->iwomipay_get_id()),
                'desc_tip'    => true,
            ),
            'description' => array(
                'title'       => __('Description', $this->iwomipay_get_id()),
                'type'        => 'textarea',
                'description' => __('Description that will be displayed on your checkout page', $this->iwomipay_get_id()),
                'default'     => __('Visa/Mastercard Seemless Payment For Woocommerce', $this->iwomipay_get_id()),
                'desc_tip'    => true,
            ),

            // Production mode credentials
            'sectionTwo' => array(
                'title' => __('Production Credentials', $this->iwomipay_get_id()),
                'type' => 'title',
            ),
            $this->iwomipay_get_fields('iwomipayUser') => $this->iwomipay_set_field('Username', 'text', 'xxx', 'API username, contact IWOMIPAY admin'),
            $this->iwomipay_get_fields('iwomipayPassword') => $this->iwomipay_set_field('Password', 'password', 'xxx', 'API password, contact IWOMIPAY admin'),
            $this->iwomipay_get_fields('iwomipayCrediKey') => $this->iwomipay_set_field(strtoupper($this->gateway) . ' Credi Apikey', 'text', 'xxx', 'Get it from the API keys menu in your Iwomipay Portal'),
            $this->iwomipay_get_fields('iwomipayCrediSecret') => $this->iwomipay_set_field(strtoupper($this->gateway) . ' Credi ApiSecret', 'password', 'xxx', 'Get it from the API keys menu in your Iwomipay Portal'),

            // Sandbox mode credential
            'sectionThree' => array(
                'title' => __('Sandbox Credentials', $this->iwomipay_get_id()),
                'type' => 'title',
            ),
            $this->iwomipay_get_fields('iwomipayUserSandbox') => $this->iwomipay_set_field('Username', 'text', 'xxx', 'Get it from the sandbox documentation on Iwomipay landing page'),
            $this->iwomipay_get_fields('iwomipayPasswordSandbox') => $this->iwomipay_set_field('Password', 'password', 'xxx', 'Get it from the sandbox documentation on Iwomipay landing page'),
            $this->iwomipay_get_fields('iwomipayCrediKeySandbox') => $this->iwomipay_set_field(strtoupper($this->gateway) . ' Credi ApiKey', 'text','xxx', 'Get it from the sandbox documentation on Iwomipay landing page'),
            $this->iwomipay_get_fields('iwomipayCrediSecretSandbox') => $this->iwomipay_set_field(strtoupper($this->gateway) . ' Credi ApiSecret', 'password', 'xxx', 'Get it from the sandbox documentation on Iwomipay landing page'),

            // API Mode
            'sectionFour' => array(
                'title' => __('Api mode', $this->iwomipay_get_id()),
                'type' => 'title',
            ),
            $this->iwomipay_get_fields('apiBaseUrl') => $this->iwomipay_set_field('API base url', 'text', 'https://www.pay.iwomitechnologies.com:8443/iwomipay_prod/', 'Get it from the documentation on Iwomipay landing page'),
            $this->iwomipay_get_fields('apiBaseUrlSandbox') => $this->iwomipay_set_field('Sandbox API base url', 'text', 'https://www.pay.iwomitechnologies.com:8443/iwomipay_sandbox/', 'Get it from the sandbox documentation on Iwomipay landing page'),

            $this->iwomipay_get_fields('environment') => array(
                'title'        => __('Payment Mode', $this->iwomipay_get_id()),
                'type'        => 'select',
                'desc_tip' => true,
                'description' => __('Select Sandbox when testing and Production when going live.', $this->iwomipay_get_id()),
                'default'    => 'test',
                'options' => array(
                    'test' => 'Sandbox',
                    'live' => 'Production'
                )
            ),
        ));
    }

    public function iwomipay_check_email(?string $email = null): ?string
    {

        return ($email != null && filter_var($email, FILTER_VALIDATE_EMAIL)) ? $email : null;
    }

    public function iwomipay_check_phone(?string $phone = null): ?string
    {

        return ($phone != null && strlen($phone) === 9) ? '237' . $phone : null;
    }

    public function iwomipay_valide_form(): array
    {

        $form = WC()->checkout()->get_posted_data();
        return [
            'email' => $form['billing_email'] ?? 'info@iwomitechnologies.com',
            'country' => strtolower($form['billing_country']) ?? 'cm',
            'tel' => $form['billing_phone'] ?? '237676332621',
            'first_name' => $form['billing_first_name'] ?? 'IWOMI',
            'last_name' => $form['billing_last_name'] ?? 'Technologies',
            'address' => $form['billing_address_1'] ?? 'Bonamoussadi',
            'city' => $form['billing_city'] ?? 'Douala'
        ];
    }

    public function iwomipay_true_var(string $var): string
    {

        $sandbox = $var . 'Sandbox';
        return ($this->iwomipayEnvironment === 'live') ? $this->$var : $this->$sandbox;
    }

    public function iwomipay_get_token()
    {

        if ($this->iwomipayToken['expired_time'] && $this->iwomipayToken['expired_time'] < time()) {

            return $this->iwomipayToken['token'];
        }

        $login = $this->login($this->iwomipay_true_var('iwomipayUser'), $this->iwomipay_true_var('iwomipayPassword'));
        if (!$login['error']) {

            $login = json_decode($login['data']);
            if (isset($login->token) && $login->status == "01") {

                $this->iwomipayToken['token'] = $login->token;
                $this->iwomipayToken['expired_time'] = time() + 600;
                return $this->iwomipayToken['token'];
            } else {
    
                wc_add_notice('An unknown error while connecting. line: 254, Message: ' ($login->message ?? '/'), 'error');
                return null;
            }
        } else {

            wc_add_notice('Unknown API error. Line: 259, Message: ' . $login['error'], 'error');
            return null;
        }
    }

    public function iwomipay_get_key()
    {

        return [
            'api_key' => $this->iwomipay_true_var('iwomipayCrediKey'),
            'api_secret' => $this->iwomipay_true_var('iwomipayCrediSecret'),
            'gateway' => $this->gateway,
            'base_url' => $this->iwomipay_true_var('iwomipayApiBaseUrl')
        ];
    }

    public function login(string $username, string $password): array
    {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $this->iwomipay_true_var('iwomipayApiBaseUrl') . 'authenticate',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => '{
                "username": "' . $username . '",
                "password": "' . $password . '"
            }',
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);
        $error = curl_errno($curl) ? curl_error($curl) : null;
        curl_close($curl);

        return [
            'error' => $error,
            'data' => $response
        ];
    }

    public function iwomipay_check_transaction($transaction_id): array
    {

        $token = $this->iwomipay_get_token();
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $this->iwomipay_true_var('iwomipayApiBaseUrl') . 'iwomipayStatus/' . $transaction_id,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'Authorization: Bearer ' . $token
            ),
        ));

        $response = curl_exec($curl);
        $error = curl_errno($curl) ? curl_error($curl) : null;
        curl_close($curl);

        return [
            'error' => $error,
            'data' => json_decode($response)
        ];
    }

    // We're processing the payments here
    public function process_payment($order_id)
    {

        global $woocommerce;
        $order = wc_get_order($order_id);
        $token = $this->iwomipay_get_token();

        if (!$token) {

            return false;
        }

        $key = $this->iwomipay_get_key();
        $form = $this->iwomipay_valide_form();
        $body = wp_json_encode([
            'op_type' => 'credit',
            'type' => $key['gateway'],
            'amount' => $order->get_total(),
            'external_id' => 'jg' . time(),
            'motif' => 'Paiement website',
            'email' => $form['email'],
            'tel' => $form['tel'],
            'country' => $form['country'],
            'currency' => strtolower($order->get_currency()),
            'success_url' => $this->get_return_url($order),
            'failed_url' => wc_get_checkout_url(),
            'callback_url' => plugin_dir_url(__FILE__) . 'endpoint.php?order_id=' . $order_id,
            'first_name' => $form['first_name'],
            'last_name' => $form['last_name'],
            'address' => $form['address'],
            'city' => $form['city']
        ]);

        $options = [
            'method'      => 'POST',
            'body'        => $body,
            'headers'     => [
                'AccountKey'    => base64_encode($key['api_key'] . ':' . $key['api_secret']),
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json'
            ],
            'data_format' => 'body',
            'httpversion' => '1.0',
            'timeout'     => 45,
            'sslverify'   => false
        ];

        // Your API interaction could be built with wp_remote_post()
        $response = wp_remote_post($key['base_url'] . 'iwomipay', $options);

        if (!is_wp_error($response)) {

            $body = json_decode($response['body'], true);
            file_put_contents('body.txt', json_encode($body));
            if (isset($body['status']) && $body['status'] == "1000") {

                if ($body['message'] == "Open the link and confirm your payment" || $body['message'] == "Operation initiated successfully, kindly redirect to the link") {

                    // Mark as on-hold (we're while we redirect to payment gateway for payment completion)
                    $order->update_status('processing');

                    // Redirect to the payunit payment page
                    return array(
                        'result' => 'success',
                        'redirect' => $body['redirectUrl']
                    );
                } else {

                    wc_add_notice($body['message'] ?? 'An error has occurred internally, please try again later !!!', 'error');
                    return;
                }
            } else {

                wc_add_notice($body['message'] ?? 'Error when initiating the transaction. Please try again later.', 'error');
                return;
            }
        } else {

            wc_add_notice('Connection error. Line: 457, Message: ' . ($response->get_error_message() ?? '/'), 'error');
            return;
        }
    }

    // Output for the order received page.
    public function thankyou_page()
    {

        if ($this->description) {

            echo wpautop(wptexturize($this->description));
        }
    }
}

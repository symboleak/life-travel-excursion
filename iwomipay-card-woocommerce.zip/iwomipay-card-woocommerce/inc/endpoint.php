<?php

if (file_exists(dirname(__DIR__, 4) . DIRECTORY_SEPARATOR . 'wp-load.php')) {

  require_once dirname(__DIR__, 4) . DIRECTORY_SEPARATOR . 'wp-load.php';

  $body = file_get_contents('php://input');
  file_put_contents('status.txt', $body);
  $body = json_decode($body);
  if (isset($_GET['order_id'])) {

    if (isset($body->status)) {

      $order = wc_get_order($_GET['order_id']);
      if ($body->status === "01") {

        $order->payment_complete();
        $order->update_status('completed');
        if (version_compare(WOOCOMMERCE_VERSION, "2.6") <= 0) {
  
          $order->reduce_order_stock();
        } else {
    
          wc_reduce_stock_levels( $order_id );
        }
      } elseif ($body->status === "100") {

        $order->update_status('failed');
      }
    }
  }
}


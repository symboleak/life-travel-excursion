<?php
/**
 * Plugin Name: IWOMIPAY for WooCommerce
 * Plugin URI: https://www.pay.iwomitechnologies.com/
 * Description: Online payment system using MTN Mobile Money (MOMO), Orange Money (OM), Paypal and also supporting Visa and MasterCard bank cards.
 * Author: IWOMI TECHNOLOGIES LTD
 * Author URI: https://www.iwomitechnologies.com/
 * Version: 1.0.0
 * Text Domain: wc-iwomipay-all
 * Domain Path: /i18n/languages/
 * Developer: Jifitech Group, Inc.
 * Requires at least: 5.5
 * Tested up to: 5.7.1
 * Requires PHP: 7.2
 * License: GPLv2 or later
 * License URL: http://www.gnu.org/licenses/gpl-2.0.txt
 * Copyright: (c) 2021 IWOMI TECHNOLOGIES LTD. (info@iwomitechnologies.com) and WooCommerce
 *
 * @package   WC-Iwomipay
 * @author    IWOMI TECHNOLOGIES LTD
 * @category  Admin
 * @copyright Copyright: (c) 2021 IWOMI TECHNOLOGIES LTD. (info@iwomitechnologies.com) and WooCommerce
 * @license   http://www.gnu.org/licenses/gpl-2.0.txt
 *
 * Online payment system using MTN Mobile Money (MOMO), Orange Money (OM), Paypal and also supporting Visa and MasterCard bank cards.
 */
 
defined( 'ABSPATH' ) or exit;

$GLOBALS['ciphering'] = "AES-128-CTR";

// Use OpenSSl Encryption method 
$GLOBALS['iv_length'] = openssl_cipher_iv_length($GLOBALS['ciphering']);

// Non-NULL Initialization Vector for encryption 
$GLOBALS['encryption_iv'] = '1234567891011121';

// Store the encryption / decryption key 
$GLOBALS['ecryption_key'] = "IwoMiPaySaddI";

$GLOBALS['options_key'] = 0;

// Use openssl_encrypt() function to encrypt the data 
// $GLOBALS['encryption'] = openssl_encrypt($simple_string, $ciphering, $encryption_key, $options, $encryption_iv); 
$GLOBALS['encryption'] = "1JCmtBpuWTzopyYFhzgRHU0rvKAyt5H+qJFfAdl/jcCk2JrDm2DIlA==";

// Use openssl_decrypt() function to decrypt the data 
$GLOBALS['decryption'] = openssl_decrypt(
    $GLOBALS['encryption'],
    $GLOBALS['ciphering'],
    $GLOBALS['ecryption_key'],
    $GLOBALS['options_key'],
    $GLOBALS['encryption_iv']
);

// Make sure WooCommerce is active
if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {

	return;
}

/**
 * Add the gateway to WC Available Gateways
 * 
 * @since         1.0.0
 * @param array   $gateways all available WC gateways
 * @return array  $gateways all WC gateways + IWOMIPAY gateway
 */
function wc_iwomipay( $gateways ): array
{

	$gateways[] = 'IwomipayGateway';
	return $gateways;
}
add_filter( 'woocommerce_payment_gateways', 'wc_iwomipay');

/**
 * Adds plugin page links
 * 
 * @since          1.0.0
 * @param array    $links all plugin links
 * @return array   $links all plugin links + our custom links (i.e., "Settings")
 */
function wc_iwomipay_plugin_links( $links ): array
{

	$plugin_links = [
        '<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=wc_iwomipay_settings' ) . '">' . __( 'Configure', 'wc-iwomipay-all' ) . '</a>'
    ];

	return array_merge( $plugin_links, $links );
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'wc_iwomipay_plugin_links' );

/**
 * IWOMIPAY Online payment gateway.
 *
 * @class 		 IwomipayGateway
 * @extends		 WC_Payment_Gateway
 * @version		 1.0.0
 * @package		 WooCommerce/Classes/Payment
 * @author 		 Jifitech Group
 * @return void
 */
add_action( 'plugins_loaded', 'wc_iwomipay_paiment_init', 11 );

function wc_iwomipay_paiment_init(): void
{

	if (class_exists('WC_Payment_Gateway')) {

        require_once plugin_dir_path(__FILE__) . DIRECTORY_SEPARATOR . 'inc' . DIRECTORY_SEPARATOR . 'IwomipayGateway.php';
        require_once plugin_dir_path(__FILE__) . DIRECTORY_SEPARATOR . 'inc' . DIRECTORY_SEPARATOR . 'IwomipayUpdate.php';
        new IwomipayUpdate( __FILE__, 'github-username', 'github-repositry', 'github-access-token' );
    }
}

<?php

class IwomipayGateway extends WC_Payment_Gateway
{

    /**
     * Constructor for the IWOMIPAY gateway.
     */
    public function __construct()
    {

        $this->gateway = 'all';
        $this->array_gateway = ['momo', 'om', 'paypal', 'card'];
        $this->response_message = [
            "Operation Pending",
            "Open the link and confirm your payment",
            "Status is Pending, Operation successfully initiated",
            "Operation initiated successfully, kindly redirect to the link",
            "Operation successfully initiated, Client Confirm with your PIN Code"
        ];
        $this->success_response_messages = [
            'SUCCESS',
            'SUCCESSFUL',
            'SUCCESSFULL'
        ];

        $this->id                 = 'wc_iwomipay_payment';
        $this->icon               = apply_filters('woocommerce_iwomipay_icon', $this->iwomipay_get_assets('icon.png'));
        $this->has_fields         = false;
        $this->method_title       = __('Pay with IWOMIPAY', $this->iwomipay_get_id());
        $this->method_description = __('Online payment system using MTN Mobile Money (MOMO), Orange Money (OM), Paypal and also supporting Visa and MasterCard bank cards.', $this->iwomipay_get_id());

        // Load the settings.
        $this->init_form_fields();
        $this->init_settings();

        // Define user set variables
        $this->sectionOne   = $this->get_option('sectionOne');
        $this->title        = $this->get_option('title');
        $this->description  = $this->get_option('description');

        /**
         * Production mode credentials
         */
        $this->sectionTwo = $this->get_option('sectionTwo');

        // Account Identifiants
        $this->iwomipayUser = $this->iwomipay_init_fields('iwomipayUser');
        $this->iwomipayPassword = $this->iwomipay_init_fields('iwomipayPassword');

        // MTN Mobile Money Credit Credentials 
        $this->iwomipayMomoCrediKey = $this->iwomipay_init_fields('iwomipayMomoCrediKey');
        $this->iwomipayMomoCrediSecret = $this->iwomipay_init_fields('iwomipayMomoCrediSecret');

        // Orange Money Credit Credentials 
        $this->iwomipayOmCrediKey = $this->iwomipay_init_fields('iwomipayOmCrediKey');
        $this->iwomipayOmCrediSecret = $this->iwomipay_init_fields('iwomipayOmCrediSecret');

        // Paypal Credit Credentials 
        $this->iwomipayPaypalCrediKey = $this->iwomipay_init_fields('iwomipayPaypalCrediKey');
        $this->iwomipayPaypalCrediSecret = $this->iwomipay_init_fields('iwomipayPaypalCrediSecret');

        // Card Credit Credentials 
        $this->iwomipayCardCrediKey = $this->iwomipay_init_fields('iwomipayCardCrediKey');
        $this->iwomipayCardCrediSecret = $this->iwomipay_init_fields('iwomipayCardCrediSecret');

        /**
         * Sandbox mode credentials
         */
        $this->sectionThree = $this->get_option('sectionThree');

        // Account Identifiants
        $this->iwomipayUserSandbox = $this->iwomipay_init_fields('iwomipayUserSandbox');
        $this->iwomipayPasswordSandbox = $this->iwomipay_init_fields('iwomipayPasswordSandbox');

        // MTN Mobile Money Credit Credentials 
        $this->iwomipayMomoCrediKeySandbox = $this->iwomipay_init_fields('iwomipayMomoCrediKeySandbox');
        $this->iwomipayMomoCrediSecretSandbox = $this->iwomipay_init_fields('iwomipayMomoCrediSecretSandbox');

        // Orange Money Credit Credentials 
        $this->iwomipayOmCrediKeySandbox = $this->iwomipay_init_fields('iwomipayOmCrediKeySandbox');
        $this->iwomipayOmCrediSecretSandbox = $this->iwomipay_init_fields('iwomipayOmCrediSecretSandbox');

        // Paypal Credit Credentials 
        $this->iwomipayPaypalCrediKeySandbox = $this->iwomipay_init_fields('iwomipayPaypalCrediKeySandbox');
        $this->iwomipayPaypalCrediSecretSandbox = $this->iwomipay_init_fields('iwomipayPaypalCrediSecretSandbox');

        // Card Credit Credentials 
        $this->iwomipayCardCrediKeySandbox = $this->iwomipay_init_fields('iwomipayCardCrediKeySandbox');
        $this->iwomipayCardCrediSecretSandbox = $this->iwomipay_init_fields('iwomipayCardCrediSecretSandbox');

        // Base Url
        $this->sectionFour = $this->get_option('sectionFour');
        $this->iwomipayApiBaseUrl = $this->iwomipay_init_fields('iwomipayApiBaseUrl');
        $this->iwomipayApiBaseUrlSandbox = $this->iwomipay_init_fields('iwomipayApiBaseUrlSandbox');
        $this->iwomipayEnvironment = $this->iwomipay_init_fields('iwomipayEnvironment');

        $this->iwomipayOptions = [];
        $this->iwomipayToken = [
            'token' => null,
            'expired_time' => null
        ];

        // Actions
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));

        // Add Custom fields
        add_filter( 'woocommerce_gateway_description', [$this, 'iwomipay_add_custom_fields'], 20, 2 );
    }

    public function iwomipay_get_time(): int
    {
    
        return time();
    }

    public function iwomipay_get_assets(string $asset): string
    {
    
        return plugins_url('..' . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . $asset, __FILE__);
    }

    public function iwomipay_get_post(): array
    {
    
        return WC()->checkout()->get_posted_data();
    }

    public function iwomipay_get_id(): string
    {
    
        return 'wc-iwomipay-' . $this->gateway;
    }

    public function iwomipay_add_custom_fields( $description, $payment_id ): string
    {

        if( $this->id === $payment_id ) {

            ob_start();
            echo '<style>div.payment_method_wc_iwomipay_payment {margin-top:5px;padding:10px;background:linear-gradient(90deg,#188235,#688614);}.payment_method_wc_iwomipay_payment>p{color:#fff;font-size:14px;text-align:center;}.payment_method_wc_iwomipay_payment .wc_iwomipay_gateway_html_content .wc_iwomipay_gateway_html_label{display:flex;justify-content: space-around;margin-top: 10px;}.payment_method_wc_iwomipay_payment .wc_iwomipay_gateway_html_content h4{text-align:center;margin:15px 5px 5px 5px;font-size:12px;line-height:12px;font-weight:bold;color:#000;}.payment_method_wc_iwomipay_payment .wc_iwomipay_gateway_html_content .wc_iwomipay_gateway_html_label > label{position:relative;text-align:center;}.payment_method_wc_iwomipay_payment .wc_iwomipay_gateway_html_content .wc_iwomipay_gateway_html_label > label > input {position:absolute;opacity:0;}.payment_method_wc_iwomipay_payment .wc_iwomipay_gateway_html_content .wc_iwomipay_gateway_html_label > label > span {display:block;font-size:11px;color:#fff;max-width:60px;line-height:12px;margin-top:5px;transition:0.2s ease-in-out;}.payment_method_wc_iwomipay_payment .wc_iwomipay_gateway_html_content .wc_iwomipay_gateway_html_label > label > img {height:50px;width: 50px;padding:2px;transition:0.2s ease-in-out;}.payment_method_wc_iwomipay_payment .wc_iwomipay_gateway_html_content .wc_iwomipay_gateway_html_label > label > input:checked + img {border: 2px solid #fff;}.payment_method_wc_iwomipay_payment .wc_iwomipay_gateway_html_content .wc_iwomipay_gateway_html_label > label > input:checked + img + span {color:#000;}.payment_method_wc_iwomipay_payment .wc_iwomipay_gateway_html_content .wc_iwomipay_gateway_html_phone{position:relative;margin-top:10px;}.payment_method_wc_iwomipay_payment .wc_iwomipay_gateway_html_content .wc_iwomipay_gateway_html_phone span{position:absolute;padding: 0 10px;background:rgba(0, 0, 0, 0.05);height:40px;line-height:40px;font-weight:bold;font-size:15px;}.payment_method_wc_iwomipay_payment .wc_iwomipay_gateway_html_content .wc_iwomipay_gateway_html_phone input{width:100%;height:40px;min-height:40px;line-height:30px;padding-left:60px;}</style>
            <div class="wc_iwomipay_gateway_html_content">
                <h4>Select a payment method</h4>
                <div class="wc_iwomipay_gateway_html_label"><label for="wc_iwomipay_gateway_select_momo" onclick="iwomipay_active_input(this,\'momo\')"><input type="radio" name="wc_iwomipay_gateway_select" id="wc_iwomipay_gateway_select_momo" value="momo"/><img src="' . $this->iwomipay_get_assets('momo.jpg') . '" title="Mtn Mobile Money" alt="Mtn Mobile Money"/><span>Mtn Mobile Money</span></label><label for="wc_iwomipay_gateway_select_om" onclick="iwomipay_active_input(this,\'om\')"><input type="radio" name="wc_iwomipay_gateway_select" id="wc_iwomipay_gateway_select_om" value="om"/><img src="' . $this->iwomipay_get_assets('om.jpg') . '" title="Orange Money" alt="Orange Money"/><span>Orange Money</span></label><label for="wc_iwomipay_gateway_select_paypal" onclick="iwomipay_active_input(this,\'paypal\')"><input type="radio" name="wc_iwomipay_gateway_select" id="wc_iwomipay_gateway_select_paypal" value="paypal"/><img src="' . $this->iwomipay_get_assets('paypal.jpg') . '" title="Paypal" alt="Paypal"/><span>Paypal</span></label><label for="wc_iwomipay_gateway_select_card" onclick="iwomipay_active_input(this,\'card\')"><input type="radio" name="wc_iwomipay_gateway_select" id="wc_iwomipay_gateway_select_card" value="card"/><img src="' . $this->iwomipay_get_assets('card.jpeg') . '" title="Visa and MasterCard" alt="Visa and MasterCard"/><span>Visa MasterCard</span></label></div>
                <div class="wc_iwomipay_gateway_html_phone"style="display:none;"><span class="">+237</span><input type="number" name="wc_iwomipay_gateway_select_phone" id="" placeholder="6********"></div>
                <script>function iwomipay_active_input(element,gateway){const div=element.parentNode.nextElementSibling;if(gateway=="momo"||gateway=="om"){if(div.style.display==="none"){div.style.display="block";}}else{if(div.style.display==="block"){div.style.display="none";}}}</script>
            </div>';
            $description .= ob_get_clean();
        }
        return $description;
    }

    public function iwomipay_init_fields( string $option ): string
    {

        return $this->get_option($option . $this->gateway);
    }

    public function iwomipay_get_fields( string $field ): string
    {

        return $field . $this->gateway;
    }

    public function iwomipay_set_field( string $field, string $type = 'text', string $default = 'xxx', string $description = '' ): array
    {

        return array(
            'title' => __($field, $this->iwomipay_get_id()),
            'type' => $type,
            'default' => __($default, $this->iwomipay_get_id()),
            'desc_tip' => true,
            'description' => __($description, $this->iwomipay_get_id())
        );
    }

    public function init_form_fields()
    {

        $this->form_fields = apply_filters('wc_iwomipay_fields', [

            'sectionOne' => [
                'title' => __('Gateway Settings', $this->iwomipay_get_id()),
                'type' => 'title',
            ],

            'enabled' => [
                'title'   => __('Enable/Disable gateway', $this->iwomipay_get_id()),
                'type'    => 'checkbox',
                'label'   => __('Enable or Disable payments with IWOMIPAY', $this->iwomipay_get_id()),
                'default' => 'no'
            ],

            'title' => [
                'title'       => __('Gateway Title', $this->iwomipay_get_id()),
                'type'        => 'text',
                'description' => __('Title that will be displayed on your checkout page', $this->iwomipay_get_id()),
                'default'     => __('Pay with IWOMIPAY', $this->iwomipay_get_id()),
                'desc_tip'    => true,
            ],

            'description' => [
                'title'       => __('Description', $this->iwomipay_get_id()),
                'type'        => 'textarea',
                'description' => __('Description that will be displayed on your checkout page', $this->iwomipay_get_id()),
                'default'     => __('Transparent online payment solution for Woocommerce.', $this->iwomipay_get_id()),
                'desc_tip'    => true,
            ],

            // Production mode credentials
            'sectionTwo' => [
                'title' => __('Production Credentials', $this->iwomipay_get_id()),
                'type' => 'title',
            ],
            $this->iwomipay_get_fields('iwomipayUser') => $this->iwomipay_set_field('Username', 'text', 'xxx', 'API username, contact IWOMIPAY admin'),
            $this->iwomipay_get_fields('iwomipayPassword') => $this->iwomipay_set_field('Password', 'password', 'xxx', 'API password, contact IWOMIPAY admin'),

            $this->iwomipay_get_fields('iwomipayMomoCrediKey') => $this->iwomipay_set_field('MOMO Credit Apikey', 'text', 'xxx', 'Get it from the API keys menu in your Iwomipay Portal'),
            $this->iwomipay_get_fields('iwomipayMomoCrediSecret') => $this->iwomipay_set_field('MOMO Credit ApiSecret', 'password', 'xxx', 'Get it from the API keys menu in your Iwomipay Portal'),

            $this->iwomipay_get_fields('iwomipayOmCrediKey') => $this->iwomipay_set_field('OM Credit Apikey', 'text', 'xxx', 'Get it from the API keys menu in your Iwomipay Portal'),
            $this->iwomipay_get_fields('iwomipayOmCrediSecret') => $this->iwomipay_set_field('OM Credit ApiSecret', 'password', 'xxx', 'Get it from the API keys menu in your Iwomipay Portal'),

            $this->iwomipay_get_fields('iwomipayPaypalCrediKey') => $this->iwomipay_set_field('Paypal Credit Apikey', 'text', 'xxx', 'Get it from the API keys menu in your Iwomipay Portal'),
            $this->iwomipay_get_fields('iwomipayPaypalCrediSecret') => $this->iwomipay_set_field('Paypal Credit ApiSecret', 'password', 'xxx', 'Get it from the API keys menu in your Iwomipay Portal'),

            $this->iwomipay_get_fields('iwomipayCardCrediKey') => $this->iwomipay_set_field('Card Credit Apikey', 'text', 'xxx', 'Get it from the API keys menu in your Iwomipay Portal'),
            $this->iwomipay_get_fields('iwomipayCardCrediSecret') => $this->iwomipay_set_field('Card Credit ApiSecret', 'password', 'xxx', 'Get it from the API keys menu in your Iwomipay Portal'),


            // Sandbox mode credential
            'sectionThree' => [
                'title' => __('Sandbox Credentials', $this->iwomipay_get_id()),
                'type' => 'title',
            ],
            $this->iwomipay_get_fields('iwomipayUserSandbox') => $this->iwomipay_set_field('Username', 'text', 'xxx', 'Get it from the sandbox documentation on Iwomipay landing page'),
            $this->iwomipay_get_fields('iwomipayPasswordSandbox') => $this->iwomipay_set_field('Password', 'password', 'xxx', 'Get it from the sandbox documentation on Iwomipay landing page'),

            $this->iwomipay_get_fields('iwomipayMomoCrediKeySandbox') => $this->iwomipay_set_field('MOMO Credit ApiKey', 'text','xxx', 'Get it from the sandbox documentation on Iwomipay landing page'),
            $this->iwomipay_get_fields('iwomipayMomoCrediSecretSandbox') => $this->iwomipay_set_field('MOMO Credit ApiSecret', 'password', 'xxx', 'Get it from the sandbox documentation on Iwomipay landing page'),

            $this->iwomipay_get_fields('iwomipayOmCrediKeySandbox') => $this->iwomipay_set_field('OM Credit ApiKey', 'text','xxx', 'Get it from the sandbox documentation on Iwomipay landing page'),
            $this->iwomipay_get_fields('iwomipayOmCrediSecretSandbox') => $this->iwomipay_set_field('OM Credit ApiSecret', 'password', 'xxx', 'Get it from the sandbox documentation on Iwomipay landing page'),

            $this->iwomipay_get_fields('iwomipayPaypalCrediKeySandbox') => $this->iwomipay_set_field('Paypal Credit ApiKey', 'text','xxx', 'Get it from the sandbox documentation on Iwomipay landing page'),
            $this->iwomipay_get_fields('iwomipayPaypalCrediSecretSandbox') => $this->iwomipay_set_field('Paypal Credit ApiSecret', 'password', 'xxx', 'Get it from the sandbox documentation on Iwomipay landing page'),

            $this->iwomipay_get_fields('iwomipayCardCrediKeySandbox') => $this->iwomipay_set_field('Card Credit ApiKey', 'text','xxx', 'Get it from the sandbox documentation on Iwomipay landing page'),
            $this->iwomipay_get_fields('iwomipayCardCrediSecretSandbox') => $this->iwomipay_set_field('Card Credit ApiSecret', 'password', 'xxx', 'Get it from the sandbox documentation on Iwomipay landing page'),

            // API Mode
            'sectionFour' => [
                'title' => __('Api mode', $this->iwomipay_get_id()),
                'type' => 'title',
            ],
            $this->iwomipay_get_fields('iwomipayApiBaseUrl') => $this->iwomipay_set_field('API base url', 'text', 'https://www.pay.iwomitechnologies.com/api/iwomipay_prodv1', 'Contact Iwomipay Support'),
            $this->iwomipay_get_fields('iwomipayApiBaseUrlSandbox') => $this->iwomipay_set_field('Sandbox API base url', 'text', 'https://www.pay.iwomitechnologies.com/api/iwomipay_sandbox', 'Get it from the sandbox documentation on Iwomipay landing page'),
            $this->iwomipay_get_fields('iwomipayEnvironment') => [
                'title'        => __('Payment Mode', $this->iwomipay_get_id()),
                'type'         => 'select',
                'desc_tip'     => true,
                'description'  => __('Select Sandbox when testing and Production when going live.', $this->iwomipay_get_id()),
                'default'      => 'test',
                'options'      => [
                    'test' => 'Sandbox',
                    'live' => 'Production'
                ]
            ]
        ]);
    }


    /**
     * iwomipay_check_email
     *
     * @param  null|string $email
     * @return null|string
     */
    public function iwomipay_check_email( ?string $email = null ): ?string
    {

        return ($email != null && filter_var($email, FILTER_VALIDATE_EMAIL)) ? $email : null;
    }

    
    /**
     * iwomipay_check_phone
     *
     * @param  null|string $phone
     * @return null|string
     */
    public function iwomipay_check_phone( ?string $phone = null ): ?string
    {

        return ($phone != null && strlen($phone) === 9) ? '237' . $phone : null;
    }


    /**
     * iwomipay_check_field
     *
     * @param  array $data
     * @param  string $field
     * @param  string $default
     * @return string
     */
    public function iwomipay_check_field( array $data, string $field, string $default ): string
    {

        return (isset($data[$field]) && !empty($data[$field])) ? $data[$field] : $default;
    }


    /**
     * iwomipay_valide_form
     *
     * @param  array $form
     * @return array
     */
    public function iwomipay_valide_form( array $form ): array
    {

        return [
            'email' => $this->iwomipay_check_field($form, 'billing_email', 'info@iwomitechnologies.com'),
            'country' => $this->iwomipay_check_field($form, 'billing_country', 'cm'),
            'tel' => $this->iwomipay_check_field($form, 'billing_phone', '237676332621'),
            'first_name' => $this->iwomipay_check_field($form, 'billing_first_name', 'IWOMI'),
            'last_name' => $this->iwomipay_check_field($form, 'billing_last_name', 'Technologies'),
            'address' => $this->iwomipay_check_field($form, 'billing_address_1', 'Bonamoussadi'),
            'city' => $this->iwomipay_check_field($form, 'billing_city', 'Douala')
        ];
    }


    /**
     * iwomipay_true_var
     *
     * @param  string $var
     * @return string
     */
    public function iwomipay_true_var( string $var, bool $baseUrl = false): string
    {

        $sandbox = $var . 'Sandbox';
        $value = ($this->iwomipayEnvironment === 'live') ? $this->$var : $this->$sandbox;

        if ($baseUrl === true) {

            return (substr($value, -1) === "/") ? $value : $value . "/";
        }
        return $value;
    }


    /**
     * iwomipay_get_token
     *
     * @return null|string
     */
    public function iwomipay_get_token(): ?string
    {

        if ($this->iwomipayToken['expired_time'] && $this->iwomipayToken['expired_time'] < $this->iwomipay_get_time()) {

            return $this->iwomipayToken['token'];
        }

        $login = $this->login($this->iwomipay_true_var('iwomipayUser'), $this->iwomipay_true_var('iwomipayPassword'));
        if (!$login['error']) {

            $login = json_decode($login['data']);
            if (isset($login->token) && $login->status == "01") {

                $this->iwomipayToken['token'] = $login->token;
                $this->iwomipayToken['expired_time'] = $this->iwomipay_get_time() + 600;
                return $this->iwomipayToken['token'];
            }

            wc_add_notice('An unknown error while connecting. Line: 380, Message: ' ($login->message ?? '/'), 'error');
            return null;
        }

        wc_add_notice('Unknown API error. Line: 384, Message: ' . $login['error'], 'error');
        return null;
    }

    
    /**
     * iwomipay_get_key
     *
     * @return null|array
     */
    public function iwomipay_get_key(): ?array
    {

        $form = $this->iwomipay_get_post();
        if ($form['payment_method'] === 'wc_iwomipay_payment' && isset($_POST['wc_iwomipay_gateway_select']) && in_array($_POST['wc_iwomipay_gateway_select'], $this->array_gateway)) {

            $phone = '';
            $method = $_POST['wc_iwomipay_gateway_select'];
            if ($method === 'momo' || $method === 'om') {

                $phone = $this->iwomipay_check_phone($_POST['wc_iwomipay_gateway_select_phone'] ?? null);
                if (!$phone) {
                
                    wc_add_notice('Incorrect phone number. Please try again !!!', 'error');
                    return null;  
                }
            }

            return [
                'form' => $this->iwomipay_valide_form($form),
                'api_key' => $this->iwomipay_true_var('iwomipay' . ucfirst($method) . 'CrediKey'),
                'api_secret' => $this->iwomipay_true_var('iwomipay' . ucfirst($method) . 'CrediSecret'),
                'gateway' => $method,
                'phone' => $phone,
                'base_url' => $this->iwomipay_true_var('iwomipayApiBaseUrl', true)
            ];
        }

        wc_add_notice('An error is produced in the form, please check the information and try again.', 'error');
        return null;
    }


    /**
     * login
     *
     * @param  string $username
     * @param  string $password
     * @return array
     */
    public function login(string $username, string $password): array
    {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $this->iwomipay_true_var('iwomipayApiBaseUrl', true) . 'authenticate',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => '{
                "username": "' . $username . '",
                "password": "' . $password . '"
            }',
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);
        $error = curl_errno($curl) ? curl_error($curl) : null;
        curl_close($curl);
        return [
            'error' => $error,
            'data' => $response
        ];
    }


    /**
     * iwomipay_check_transaction
     *
     * @param  mixed $transaction_id
     * @return array
     */
    public function iwomipay_check_transaction($transaction_id): array
    {

        $token = $this->iwomipay_get_token();
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => $this->iwomipay_true_var('iwomipayApiBaseUrl', true) . 'iwomipayStatus/' . $transaction_id,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $token
            ],
        ]);

        $response = curl_exec($curl);
        $error = curl_errno($curl) ? curl_error($curl) : null;
        curl_close($curl);
        return [
            'error' => $error,
            'data' => json_decode($response)
        ];
    }

    
    /**
     * in_array
     *
     * @param  string $message
     * @param  string $array
     * @return bool
     */
    public function in_array(string $message, string $array): bool
    {

        $array = array_map('strtolower', $this->$array);
        return in_array(strtolower($message), $array);
    }

    
    /**
     * site_host
     *
     * @return string
     */
    public function site_host(): string
    {
        $site_url = site_url();
        if (substr($site_url, -1) === '/') {

            $site_url = substr($site_url, 0, -1);
        }

        $removes = ['http://', 'https://'];
        foreach($removes as $remove) {

           if(strpos($site_url, $remove) === 0) {
    
              $site_url = str_replace($remove, '', $site_url);
           }
        }

        $site_url = str_replace(':', '', $site_url);
        return $site_url;
    }


    /**
     * process_payment
     * 
     * We're processing the payments here
     * @param  mixed $order_id
     */
    public function process_payment($order_id)
    {

        global $woocommerce;
        $order = wc_get_order($order_id);
        $token = $this->iwomipay_get_token();

        if (!$token) {

            return false;
        }

        $key = $this->iwomipay_get_key();
        if (!$key) {

            return false;
        }

        $form = $key['form'];
        $body = wp_json_encode([
            'op_type' => 'credit',
            'type' => $key['gateway'],
            'amount' => $order->get_total(),
            'external_id' => 'jg_' . $order_id,
            'motif' => 'IWOMIPAY WooCommerce ' . $this->site_host(),
            'email' => $form['email'],
            'tel' => $key['phone'] != '' ? $key['phone'] : $form['tel'],
            'country' => $form['country'],
            'currency' => strtolower($order->get_currency()),
            'success_url' => $this->get_return_url($order),
            'failed_url' => wc_get_checkout_url(),
            'callback_url' => plugin_dir_url(__FILE__) . 'endpoint.php?order_id=' . $order_id,
            // 'callback_url' => 'http://4465-154-72-150-194.ngrok.io/wp-content/plugins/iwomipay-woocommerce/inc/endpoint.php?order_id=' . $order_id,
            'first_name' => $form['first_name'],
            'last_name' => $form['last_name'],
            'address' => $form['address'],
            'city' => $form['city']
        ]);

        $options = [
            'method'      => 'POST',
            'body'        => $body,
            'headers'     => [
                'AccountKey'    => base64_encode($key['api_key'] . ':' . $key['api_secret']),
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json'
            ],
            'data_format' => 'body',
            'httpversion' => '1.0',
            'timeout'     => 45,
            'sslverify'   => false
        ];

        // file_put_contents('bodySend.txt', json_encode($body)); # View body send API.
        // Your API interaction could be built with wp_remote_post()
        $response = wp_remote_post($key['base_url'] . 'iwomipay', $options);

        if (!is_wp_error($response)) {

            $body = json_decode($response['body'], true);
            // file_put_contents('body.txt', json_encode($body)); # View response API.
            if (isset($body['status']) && $body['status'] == "1000") {

                $transaction_id = 'Transcation ID: ' . $body['external_id'];
                if ($this->in_array($body['message'], 'response_message')) {

                    if ($key['gateway'] == 'momo' || $key['gateway'] == 'om') {

                        $confirm = false;
                        for ($i = 0; $i < 12; $i++) {
    
                            $resultat = $this->iwomipay_check_transaction($body['internal_id']);
                            // file_put_contents('check-' . $i . '.txt', json_encode($resultat)); # View detail current check
                            sleep(5);
                            if(!$resultat['error']) {
    
                                $resultat = $resultat['data'];
                                if (isset($resultat->status, $resultat->message)) {
    
                                    if ($resultat->status === "01" && $this->in_array($resultat->message, 'success_response_messages')) {
    
                                        $confirm = true;
                                        break;
                                    } elseif ($resultat->status === "100") {
    
                                        wc_add_notice($resultat->message, 'error');
                                        break;
                                    }
                                }
                                sleep(10);
                            } else {
    
                                wc_add_notice('An error occurred while verifying the transaction (' . $transaction_id . '). Line: 617, Message: ' . $resultat['error'], 'error');
                                break;
                            }
                        }
    
                        if ($confirm === true) {

                            // wc_add_notice('Payment successfully completed. ' . $transaction_id . '. Thank you for choosing IWOMIPAY.', 'success');
                            $order->update_status('completed');
                            if (version_compare(WOOCOMMERCE_VERSION, "2.6") <= 0) {
    
                                $order->reduce_order_stock();
                            }else {
    
                                wc_reduce_stock_levels( $order_id );
                            }

                            WC()->cart->empty_cart();
                            return array(
                                'result'         => 'success',
                                'transaction_id' => $body['external_id'],
                                'redirect'       => $this->get_return_url($order)
                            );
                        } else {

                            $order->update_status('failed');
                            wc_add_notice('Transaction failed. You did not confirm it on your mobile.', 'error');
                            return;
                        }
                    } else {

                        // Mark as on-hold (we're while we redirect to payment gateway for payment completion)
                        $order->update_status('processing');

                        // Redirect to the iwomipay payment page
                        return array(
                            'result'   => 'success',
                            'redirect' => $body['redirectUrl']
                        );
                    }
                } else {

                    wc_add_notice($body['message'] ?? 'An error has occurred internally, please try again later !!!', 'error');
                    return;
                }
            } else {

                wc_add_notice($body['message'] ?? 'Error when initiating the transaction. Please try again later.', 'error');
                return;
            }
        } else {

            wc_add_notice('Connection error. Line: 669, Message: ' . ($response->get_error_message() ?? '/'), 'error');
            return;
        }
    }


    /**
     * thankyou_page
     * 
     * Output for the order received page.  
     * @return void
     */
    public function thankyou_page(): void
    {

        if ($this->description) {

            echo wpautop(wptexturize($this->description));
        }
    }
}

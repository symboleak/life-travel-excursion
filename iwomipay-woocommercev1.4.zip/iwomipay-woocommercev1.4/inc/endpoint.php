<?php

if (file_exists(dirname(__DIR__, 4) . DIRECTORY_SEPARATOR . 'wp-load.php')) {

  require_once dirname(__DIR__, 4) . DIRECTORY_SEPARATOR . 'wp-load.php';
  $body = file_get_contents('php://input');
  $body = json_decode($body);

  if (isset($_GET['order_id'])) {

    $order_id = $_GET['order_id'];
    if (file_exists('OrderStatus.txt')) {

      $OrderStatus = json_decode(file_get_contents('OrderStatus.txt'), true);
      $OrderStatus[$order_id] = $body;
      file_put_contents('OrderStatus.txt', json_encode($OrderStatus));
    } else {
      
      file_put_contents('OrderStatus.txt', json_encode([$order_id => $body]));
    }

    if (isset($body->status)) {

      $order = wc_get_order($_GET['order_id']);
      $order_status = $order->get_status();
      if ($body->status === "01") {

        if ($order_status !== 'completed') {

          $order->payment_complete();
          $order->update_status('completed');
          if (version_compare(WOOCOMMERCE_VERSION, "2.6") <= 0) {
  
            $order->reduce_order_stock();
          } else {
      
            wc_reduce_stock_levels( $order_id );
          }
        }
      } elseif ($body->status === "100") {

        if ($order_status !== 'failed') {
          
          $order->update_status('failed');
        }
      }
    }
  }
}
